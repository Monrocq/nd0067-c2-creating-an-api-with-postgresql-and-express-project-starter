import dotenv from 'dotenv';
import {Pool} from 'pg';

dotenv.config();

const {
  host,
  host_prod,
  database,
  database_test,
  user,
  password,
  password_prod,
  ENV
} = process.env

const client = new Pool({
  host: ENV === "prod" ? host_prod : host,
  database : ENV === "test" ? database_test : database,
  user,
  password: ENV === "prod" ? password_prod : password
})

export default client